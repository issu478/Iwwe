const { cmd } = require('../command')
const axios = require('axios')

// User selections cache
const movieCache = {}
const API_KEY = 'darknero'

// ===================== 1. MOVIE SEARCH COMMAND =====================
cmd({
    pattern: 'movie',
    desc: 'Search Movies from SinhalaSub',
    react: '🎬',
    category: 'movie',
    filename: __filename
}, async (conn, mek, m, { from, reply, q, sender }) => {
    try {
        if (!q) return reply('*චිත්‍රපටයේ නම ලබා දෙන්න! (Ex: .movie Harbin)*')

        const { data } = await axios.get(
            `https://apis.sandarux.sbs/api/movie/sinhalasub-search?apikey=${API_KEY}&q=${encodeURIComponent(q)}`
        )

        const movies = data.results
        if (!movies || movies.length === 0)
            return reply('❌ ඔබ සෙවූ නමට අදාළ ප්‍රතිඵල කිසිවක් හමු නොවීය.')

        movieCache[sender] = {
            step: 'SEARCH_RESULTS',
            results: movies
        }

        let text = `*🎬 SINHALASUB SEARCH RESULTS*\n\n`
        movies.slice(0, 10).forEach((movie, i) => {
            text += `*${i + 1}.* ${movie.title}\n`
        })
        text += `\n*ඉහත අංකයකින් Reply කර වැඩි විස්තර ලබාගන්න.*`

        await conn.sendMessage(from, { text }, { quoted: mek })
    } catch (e) {
        console.error(e)
        reply('*Search කිරීමේදී දෝෂයක් සිදු විය!*')
    }
})

// ===================== 2. INTERACTIVE REPLY HANDLER =====================
cmd({ on: 'body' }, async (conn, mek, m, { body, sender, from, reply }) => {
    try {
        const cache = movieCache[sender]
        if (!cache || !/^\d+$/.test(body)) return

        const index = parseInt(body) - 1

        // -------- STEP 1: MOVIE DETAILS + QUALITY LIST --------
        if (cache.step === 'SEARCH_RESULTS') {
            const selected = cache.results[index]
            if (!selected) return

            const { data: infoData } = await axios.get(
                `https://apis.sandarux.sbs/api/movie/sinhalasub-info?apikey=${API_KEY}&url=${selected.link}`
            )

            const linksObj = infoData.links || {}
            const allLinks = [
                ...(linksObj.Pixeldrain || []),
                ...(linksObj.UsersDrive || []),
                ...(linksObj['DLServer 02'] || [])
            ]

            if (allLinks.length === 0)
                return reply('❌ මෙම චිත්‍රපටය සඳහා ඩවුන්ලෝඩ් ලින්ක්ස් හමු නොවීය.')

            movieCache[sender] = {
                step: 'QUALITY_SELECT',
                links: allLinks,
                title: selected.title,
                image: selected.image
            }

            let details = `🎬 *MOVIE DETAILS CARD* 🎬\n\n`
            details += `📝 *Title:* ${selected.title}\n`
            details += `📅 *Status:* ${infoData.status ? '✅ Available' : 'N/A'}\n\n`
            details += `📥 *QUALITY එකක් තෝරා අංකය Reply කරන්න:*`

            allLinks.forEach((dl, i) => {
                details += `\n\n*${i + 1}.* ${dl.quality} (${dl.size})`
            })

            await conn.sendMessage(
                from,
                {
                    image: { url: selected.image },
                    caption: details
                },
                { quoted: mek }
            )
        }

        // -------- STEP 2: SEND ORIGINAL VIDEO AS DOCUMENT --------
        else if (cache.step === 'QUALITY_SELECT') {
            const selectedQuality = cache.links[index]
            if (!selectedQuality) return

            reply('*📥 ඔබේ වීඩියෝව (Document) සූදානම් කරමින් පවතී. මදක් රැඳී සිටින්න...*')

            const { data: dlData } = await axios.get(
                `https://apis.sandarux.sbs/api/movie/sinhalasub-download?apikey=${API_KEY}&url=${selectedQuality.link}`
            )

            if (!dlData.success || !dlData.url)
                return reply('❌ ඩවුන්ලෝඩ් ලින්ක් එක ලබා ගැනීමට නොහැකි විය.')

            // 🔥 FIX: fetch real video file (buffer)
            const videoRes = await axios.get(dlData.url, {
                responseType: 'arraybuffer',
                headers: {
                    'User-Agent': 'Mozilla/5.0'
                }
            })

            await conn.sendMessage(
                from,
                {
                    document: Buffer.from(videoRes.data),
                    mimetype: 'video/mp4',
                    fileName: `${cache.title} [${selectedQuality.quality}].mp4`,
                    caption: `*${cache.title}*\nQuality: ${selectedQuality.quality}\n\n> Powered By Sandes Isuranda ㋡`
                },
                { quoted: mek }
            )

            delete movieCache[sender]
        }
    } catch (e) {
        console.error('Error:', e)
        reply('❌ Unexpected error occurred.')
    }
})
