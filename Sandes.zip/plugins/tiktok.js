const { cmd } = require('../command');
const axios = require('axios');

cmd({
  pattern: "tiktok",
  alias: ["tt", "ttdl", "tiktokdl"],
  desc: "Download TikTok video/audio using TikWM API",
  react: "🎬",
  category: "downloader",
  filename: __filename
},
async (conn, mek, m, { from, reply, q }) => {
  try {
    if (!q) return reply('*Please enter a valid TikTok link!*');
    
    // TikTok URL එකක්දැයි පරීක්ෂා කිරීම
    const tiktokUrl = q.trim();
    if (!tiktokUrl.includes('tiktok.com')) return reply('*Invalid TikTok URL provided!*');

    reply('🔄 Fetching details from Sandes Tik-Tok Api...');

    // TikWM API එකට request එක යැවීම
    const api = `https://tikwm.com/api/?url=${encodeURIComponent(tiktokUrl)}`;
    const response = await axios.get(api);
    const resData = response.data;

    if (resData.code !== 0 || !resData.data) {
      return reply('❌ Failed to fetch data. Make sure the link is public.');
    }

    const info = resData.data;
    const title = info.title || "TikTok Content";
    
    // Caption එක සකස් කිරීම
    const caption = `*🎬 SANDES MD TIKTOK DOWNLOADER*
╭──────────────────❖❖
┇👤 *User:* ${info.author.nickname} (@${info.author.unique_id})
┇📖 *Title:* ${title}
┇❤️ *Likes:* ${info.digg_count}
┇💬 *Comments:* ${info.comment_count}
┇🔁 *Shares:* ${info.share_count}
╰─────────────────❖❖
*Reply with a number:*

*1* ❱❱⦁ Video (No Watermark) 🎥
*2* ❱❱⦁ Video (As Document) 📂
*3* ❱❱⦁ Audio Only (MP3) 🎧

> Powered by Sandes Isuranda ㋡`;

    // මුලින්ම Thumbnail එක සමඟ විස්තර යැවීම
    const sent = await conn.sendMessage(from, {
      image: { url: info.cover }, // Video එකේ cover photo එක
      caption,
    }, { quoted: mek });

    // User ගේ response එක බලාපොරොත්තු වීම
    conn.ev.on('messages.upsert', async (msgUpdate) => {
      const msg = msgUpdate.messages[0];
      if (!msg?.message?.extendedTextMessage) return;

      const ctx = msg.message.extendedTextMessage.contextInfo;
      if (!ctx || ctx.stanzaId !== sent.key.id) return;

      const choice = msg.message.extendedTextMessage.text.trim();

      switch (choice) {
        case '1': // No Watermark Video
          await conn.sendMessage(from, {
            video: { url: info.play },
            caption: `✅ *No Watermark Video*\n\n${title}\n\n> Powered By Sandes MD ㋡`,
            mimetype: 'video/mp4'
          }, { quoted: sent });
          break;

        case '2': // Video as Document
          await conn.sendMessage(from, {
            document: { url: info.play },
            mimetype: 'video/mp4',
            fileName: `${info.id}.mp4\n\n> Powered By Sandes MD ㋡`,
            caption: `✅ *Video Document*`
          }, { quoted: sent });
          break;

        case '3': // Audio Only
          await conn.sendMessage(from, {
            audio: { url: info.music },
            mimetype: 'audio/mpeg',
            ptt: false
          }, { quoted: sent });
          break;
      }
    });

  } catch (e) {
    console.log(e);
    reply(`❌ Error: ${e.message}`);
  }
});
