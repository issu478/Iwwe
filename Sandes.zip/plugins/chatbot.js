const { cmd } = require('../command')
const { GoogleGenerativeAI } = require("@google/generative-ai");

// --- API CONFIG ---
const genAI = new GoogleGenerativeAI("AIzaSyD-M4WT_PsOAZuEoxToyNQfe2uweQSbkgM");
const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

const OWNER_NUMBER = "94716717099" // සඳැස්ගේ නම්බර් එක
let CHATBOT_STATUS = false 
global.AI_MODE = "normal" 
let menuMsgId = "" 

// --- 1. Menu Command ---
cmd({
    pattern: "chatbot",
    desc: "AI Menu",
    react: "🗣️" , 
    category: "main",
    filename: __filename
},
async (conn, mek, m, { from, reply }) => {
    const menuImage = "https://upld.zone.id/uploads/d4i0x5iq/logo.webp"
    const menuText = `
╭───────────────────────◆◆►
┇ *SANDES MD AI CONTROL PANEL*
╰──────────────────────◆◆►
╭──────────────────❖❖►
┇ *Reply The Number Below To Change!* 🔥
┇ 
┇ 01 ❯❯● *Girl AI Mode*
┇ 02 ❯❯● *Normal AI Mode*
┇ 03 ❯❯● *Kid AI Mode*
┇ 04 ❯❯● *Turn OFF Chatbot*
┇ 05 ❯❯● *Turn ON Chatbot*
╰───────────────────❖❖►
*Reply Instantly*

> Powered By Sandes Isuranda`

    const sentMsg = await conn.sendMessage(from, {
        image: { url: menuImage },
        caption: menuText
    }, { quoted: mek })

    menuMsgId = sentMsg.key.id 
})

// --- 2. AI Logic ---
cmd({
    on: "body"
},
async (conn, mek, m, { body, isCmd, senderNumber, reply }) => {
    try {
        const text = body ? body.trim() : ""
        const replyId = m.quoted ? m.quoted.id : null

        // MODE SWITCHING
        if (replyId === menuMsgId) {
            await conn.sendMessage(m.chat, { react: { text: "🎀", key: m.key } })
            if (text === "1" || text === "01") { global.AI_MODE = "girl"; return reply("➔ *Girl AI Mode Activated!*") }
            if (text === "2" || text === "02") { global.AI_MODE = "normal"; return reply("➔ *Normal AI Mode Activated!*") }
            if (text === "3" || text === "03") { global.AI_MODE = "kid"; return reply("➔ *Kid AI Mode Activated!*") }
            if (text === "4" || text === "04") { CHATBOT_STATUS = false; return reply("❌ *Chatbot Disabled!*") }
            if (text === "5" || text === "05") { CHATBOT_STATUS = true; return reply("✅ *Chatbot Enabled!*") }
        }

        // AI RESPONSE LOGIC
        if (!CHATBOT_STATUS || isCmd || !body || m.fromMe || /^[./!#]/.test(body)) return

        await conn.sendPresenceUpdate('composing', m.chat)

        let promptBase = ""
        
        // --- සඳැස්ව අඳුරගැනීමේ Logic එක ---
        let userGreeting = "User"
        if (senderNumber.includes(OWNER_NUMBER)) {
            userGreeting = "සඳැස් (Sandes Isuranda - My Creator/Owner)"
            promptBase = "You are speaking to your creator, Sandes Isuranda. Be extremely respectful, loyal, and friendly. Call him 'සඳැස්' or 'Sir' in Sinhala."
        } else {
            // වෙනත් අය සඳහා Modes
            if (global.AI_MODE === "girl") {
                promptBase = "Act as a friendly girl named Nora AI. Speak in Sinhala. Use emojis."
            } else if (global.AI_MODE === "kid") {
                promptBase = "Act as a cute small kid named Rabbit AI. Speak simple Sinhala."
            } else {
                promptBase = "Your name is Sandes AI, created by Sandes Isuranda. Speak in Sinhala."
            }
        }

        const fullPrompt = `${promptBase}\nUser (${userGreeting}) says: ${body}`;
        
        const result = await model.generateContent(fullPrompt);
        const response = await result.response;
        const aiText = response.text();

        if (aiText) {
            let finalMsg = aiText.replace(/Gemini|Google|ChatGPT|OpenAI/gi, "Sandes AI")
            return await conn.sendMessage(m.chat, { text: finalMsg }, { quoted: mek })
        }

    } catch (e) {
        console.log('[GEMINI ERROR]', e)
    }
})

